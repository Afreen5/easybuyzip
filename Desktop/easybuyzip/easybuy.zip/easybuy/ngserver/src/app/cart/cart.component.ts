import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private myservice: MyserviceService,
    private router:Router) { }
items;
  ngOnInit() {
    this.items=this.myservice.getItems()
    console.log(this.items)
  }
 
}