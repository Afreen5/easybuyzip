import { Injectable } from '@angular/core';
import {HttpInterceptor} from "@angular/common/http"
import { MyserviceService } from './myservice.service'

@Injectable({
  providedIn: 'root'
})
export class InterceptorserviceService implements HttpInterceptor {

  constructor(private myservice:MyserviceService) { }
  intercept(req,next){
    let tokenreq=req.clone({
      setHeaders:{
        authorisation:`Bearer ${this.myservice.getToken()}`
      }
      })
      return next.handle(tokenreq)
  }
}
