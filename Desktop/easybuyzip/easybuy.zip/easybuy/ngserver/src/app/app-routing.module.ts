import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { UploadComponent } from './upload/upload.component';
import { AuthGuard } from './auth.guard';
import { LoginGuard } from './login.guard';
import { CartComponent } from './cart/cart.component';

import { ProfileguardGuard } from './profileguard.guard';
import { ProfileComponent } from './profile/profile.component';
// import { SignupguardGuard } from './signupguard.guard';


const routes: Routes = [
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "login",
    component: LoginComponent,canActivate: [LoginGuard]
  },
  {
    path: "signup",
    component: SignupComponent
  },
  {
    path: "upload",
    component: UploadComponent, canActivate: [AuthGuard]
  },
  {
    path: "cart",
    component: CartComponent
  },
  {
    path: "profile/:",
    component: ProfileComponent,canActivate:[ProfileguardGuard]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
