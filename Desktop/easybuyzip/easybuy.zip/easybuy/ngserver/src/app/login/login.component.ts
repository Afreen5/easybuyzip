import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,FormControl,Validators} from '@angular/forms'
import { Router } from '@angular/router';
import { MyserviceService } from '../myservice.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login:FormGroup
  constructor(private formBuilder:FormBuilder, private myservice: MyserviceService,
    private router:Router) { 

    this.login = formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password:['', Validators.required]
    })
  }
error
result
user
  check(){
    this.myservice.login(this.login.value).subscribe((result:any)=>{
      // console.log(result)
      this.result=result
      // console.log(result.user.isSuperAdmin)
        if(result.user.isSuperAdmin){
          this.myservice.isSuperAdmin()
          localStorage.setItem("id",result.user._id);
          this.myservice.tokensaver(result.token)
         
          this.router.navigate(["/upload"])
          
        }
 else{
        this.myservice.tokensaver(result.token)
        localStorage.setItem("id",result.user._id);
        this.router.navigate(["/profile/"+result.user._id]);
       
        }
       
       // console.log(result.user._id)
      },
      
      err=>{
        this.error=err
        // this.router.navigate(["/login"])
    })
  }


  ngOnInit() {
  }

}
