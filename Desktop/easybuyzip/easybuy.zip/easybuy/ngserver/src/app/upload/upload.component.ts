import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, FormBuilder, Validators} from '@angular/forms'
import { Router } from '@angular/router';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
uploadForm:FormGroup
  constructor(private formBuilder:FormBuilder, private router:Router,
     private myservice: MyserviceService,) {
      this.uploadForm = formBuilder.group({
        pname: ['', Validators.required],
        image: ['', Validators.required]
      })
   }

  ngOnInit() {
  }
  onSelect(event){
    if(event.target.files.length>0){
      const file=event.target.files[0]
    this.uploadForm.get("image").setValue(file)
    }
  }
  error;

  addProduct(){
    let product=this.uploadForm.value;
    let fd=new FormData();
    fd.append("name",product.pname)
    fd.append("image",product.image)

    this.myservice.upload(fd).subscribe(
      result=>{
        console.log(result)
        this.router.navigate(['/home'])
      },
      err=>{
        this.error=err.error;
        console.log(err)
      }
    )
  }
  
  

}
