import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService } from '../myservice.service';
import { Content } from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor( private myservice: MyserviceService,
    private router:Router) { }
result
error
image



url="http://localhost:3000/"

  ngOnInit() {
    this.myservice.getProduct().subscribe(result=>{
      this.result=result
      for(let i in result){
this.image=result[i].myfile
console.log(this.result[0].myfile)

}

console.log(result)
    },
    err=>{
      this.error=err
    })
  }
  myProduct;
  
  addToCart(product) {
    this.myProduct=this.myservice.addToCart(product);
    window.alert('Your product has been added to the cart!');
    console.log(product)
  }
}

