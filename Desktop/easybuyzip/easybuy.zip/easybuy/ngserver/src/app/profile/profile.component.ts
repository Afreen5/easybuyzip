import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private myservice: MyserviceService,
    private router:Router) { }
id
result
  ngOnInit() {
    if(localStorage.getItem('id')){
      let profile_id=localStorage.getItem("id")
      this.id=profile_id;
      }
      this.myservice.profile(this.id).subscribe((result:any)=>{
        // console.log(result)
        this.result=result
      }
      )}
  }
