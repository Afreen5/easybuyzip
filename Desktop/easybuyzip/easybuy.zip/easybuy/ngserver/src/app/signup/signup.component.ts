import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, MaxLengthValidator, MinLengthValidator } from '@angular/forms'
import { Router } from '@angular/router';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signup: FormGroup
  constructor(private formBuilder: FormBuilder, private myservice: MyserviceService,
    private router: Router) {
    this.signup = formBuilder.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      password: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(8)]],
      cpassword: ['', Validators.required],
    })
  }
  error
  result

  addUser() {
    let pass = this.signup.value.password
    let cpass = this.signup.value.cpassword
    if (pass === cpass) {
      this.myservice.addUser(this.signup.value).subscribe(
        (result: any) => {
          this.result = result
          console.log(result)
          if (result.result) {
           this.router.navigate(['/login'])
          }else{
            this.result=result
          }
        },
        err => {
        this.error = err
          this.router.navigate(['/signup'])
        })
    }
    else {
      alert("password and confirm password do not match")
    }

  }

  ngOnInit() {
  }

}
