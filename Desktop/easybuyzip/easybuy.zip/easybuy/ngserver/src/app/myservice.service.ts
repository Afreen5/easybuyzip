import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from'@angular/common/http'
import { catchError } from 'rxjs/operators'
import {throwError} from'rxjs'
// import { HttpParams } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private http:HttpClient) { }
  url="http://localhost:3000/user/"

  addUser(users){
    return this.http.post(this.url+"signup",users)
    .pipe(catchError(this.handleError))
  }
  upload(file){
    return this.http.post(this.url+"upload",file)
    .pipe(catchError(this.handleError))
  }

  login(user){
return this.http.post(this.url+"login",user)
.pipe(catchError(this.handleError))
  }

  // getUser(){
  //   return this.http.get(this.url)
  //   .pipe(catchError(this.handleError))
  // }
  getProduct(){
    return this.http.get(this.url+"home")
    .pipe(catchError(this.handleError))
  }
  tokensaver(token){
    localStorage.setItem("token",token)
    localStorage.setItem("isToken","true")
  }

  private handleError(error:HttpErrorResponse){
    return throwError(error.error)
  }

  getToken(){
    return localStorage.getItem("token")
  }
  removeToken(){
    localStorage.removeItem("token")
    localStorage.removeItem("isSuperAdmin")
    localStorage.removeItem("isToken")
  
  }
  isSuperAdmin(){
    localStorage.setItem("isSuperAdmin","true")
  }
  items=[]

  profile(id){
    console.log(id);
    return this.http.post(this.url+"profile/"+id,id)
    .pipe(catchError(this.handleError))
      }

 
  addToCart(product) {
    this.items.push(product);
  }
  getItems() {
    return this.items;
  }

  
  
  isUser(){
    return this.http.get(this.url+"landing")
    .pipe(catchError(this.handleError))
  }

}

