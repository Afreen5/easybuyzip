import { Component } from '@angular/core';
import { MyserviceService } from './myservice.service';
import { Router } from '@angular/router';
import { ActivatedRoute, } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ngserver';
  constructor( private route:ActivatedRoute, private myservice: MyserviceService,
    private router:Router) { }
token1=false
user

ngOnInit(){
  
  this.myservice.isUser().subscribe(user=>{
this.user=user;
console.log(this.user)
  
  })

}
loggedIn
user1
id
getid(){
  if(localStorage.getItem('id')){
    let profile_id=localStorage.getItem("id")
    this.id=profile_id;
    
    }
}
isLoggedIn(){
  if(localStorage.getItem('isToken')=='true'){
    this.loggedIn=true
  }
  else{
    this.loggedIn=false
  }
}

  logOut(){
    let token=this.myservice.getToken()
    if(token){
    this.myservice.removeToken()
    this.router.navigate(['/login'])
    this.token1=false
    localStorage.removeItem("id");
    }
    else{
      alert("No user is active");
    }
  }
}
